class HomePageButton {
  final String label;
  final String route;

  const HomePageButton({required this.label, required this.route});
}